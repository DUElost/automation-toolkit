"""Independent, on-disk B8 G8 review. No imports from vendor attribution code."""
import hashlib
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path

import openpyxl
import xlrd
import xlwt

ROOT = Path(__file__).resolve().parent
SUITE = "python-tools/stability_Jira-Automation"
ARTIFACT = ROOT / "evidence"
ARTIFACT.mkdir(exist_ok=True)
VENDOR = {
    "transsion": ("Transsion_Jira_Tool_20260323", "X6851OS16", "X6851-16.3.0.021"),
    "tinno": ("Tinno_Jira_Tool_20260520", "PFDFAA", "MLD-NX3-16-261104V80"),
}
CASE = {
    71: ("review.new", [101, 102, 103]),
    72: ("review.history", [201, 202]),
    73: ("review.reject", [301]),
    74: ("review.omitted", [401]),
    75: ("review.missing", [501, 502]),
    76: ("review.fraction", [601]),
    77: ("review.outside", [701]),
    78: ("review.duplicate", [801]),
    79: ("review.nosig", [901]),
    80: ("review.text", [1001]),
    81: ("review.fractionocc", [1101]),
    82: ("review.losskey", [1201]),
}
CHECKS = []
COMMANDS = []

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def read(path):
    return json.loads(path.read_text())

def only(paths):
    files = list(paths)
    assert len(files) == 1, files
    return files[0]

def check(vendor, name, expected, actual):
    passed = expected == actual
    CHECKS.append(dict(vendor=vendor, check=name, passed=passed, expected=expected, actual=actual))
    print(vendor, "PASS" if passed else "FAIL", name, "" if passed else repr(actual), flush=True)

def run(cwd, log, argv):
    cmd = [sys.executable, *map(str, argv)]
    result = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            env=dict(PATH="/usr/bin:/bin", LANG="C.UTF-8", TZ="Asia/Shanghai"))
    log.write_bytes(result.stdout)
    COMMANDS.append(dict(cwd=str(cwd), command=shlex.join(cmd), returncode=result.returncode))
    if result.returncode:
        print(f"{log}: exit {result.returncode}", flush=True)
    return result.returncode

def key(sid, oid):
    return hashlib.sha256(f"mock-review-{sid}-{oid}".encode()).hexdigest()

def manifest(path, data, plan, version_no):
    candidates = [
        dict(signature_id=sid, occurrence_id=oid, occurrence_key=key(sid, oid),
             dle_id=f"mock-dle-{oid}", serial=f"MOCK{oid}")
        for sid, ids in data.items() for oid in ids
    ]
    payload = dict(schema="stp.jira_delivery_input/v1", plan_run_id=plan, root_plan_run_id=990,
                   platform="mtk", delivery_version_id=plan * 10 + version_no,
                   delivery_version_no=version_no, issue_ids=list(data),
                   event_ids=[x["dle_id"] for x in candidates],
                   issues=[dict(signature_id=sid, occurrence_ids=ids) for sid, ids in data.items()],
                   attribution_candidates=candidates)
    write(path, payload)
    return payload

def fixture(path, version, offset):
    book = xlwt.Workbook()
    sheet = book.add_sheet("Results")
    columns = ["Id", "Path", "Version", "ExpTime", "ExpClass", "ExpType ", "CurProcess",
               "Package", "Detail", "CausedBy", "extraTag", "Count", "Activity",
               "DeviceCount", "Rom_Ram", "Occurrence IDs"]
    rows = []
    for sid, (token, ids) in CASE.items():
        selections = {71: [[101], [102]], 75: [[501]]}.get(sid, [ids])
        for selected in selections:
            rows.append([sid + offset, f"/synthetic/{token}", version, "2026-01-01 12:00:00",
                         "Java (JE)", "Crash", token, token, f"{token} fixture",
                         f"Exception: {hashlib.sha256(token.encode()).hexdigest()}", "",
                         len(selected), token, 1, "NA", json.dumps([oid + offset for oid in selected])])
    for i, row in enumerate([columns, *rows]):
        for j, value in enumerate(row):
            sheet.write(i, j, value)
    book.save(str(path))

def sheet_rows(source):
    book = openpyxl.load_workbook(source)
    sheet = book.active
    headings, *rows = list(sheet.values)
    return headings, rows

def prepare_review(source, destination, select, edits=None, hide=None):
    headings, rows = sheet_rows(source)
    columns = {column: i for i, column in enumerate(headings)}
    def rev_row(sid):
        original = next(row for row in rows if int(row[columns["Signature ID"]]) == sid)
        adjusted = list(original)
        for col, value in (edits or {}).get(sid, {}).items():
            adjusted[columns[col]] = value
        return adjusted
    book = openpyxl.load_workbook(source)
    sheet = book.active
    sheet.delete_rows(2, sheet.max_row)
    for sid in select:
        sheet.append(rev_row(sid))
    if hide is not None:
        from openpyxl.utils import get_column_letter
        filter_col = columns["Signature ID"]
        sheet.auto_filter.ref = f"A1:{get_column_letter(sheet.max_column)}{sheet.max_row}"
        sheet.auto_filter.add_filter_column(filter_col, [str(sid) for sid in select if sid != hide])
        sheet.row_dimensions[select.index(hide) + 2].hidden = True
    book.save(destination)

def gen_args(vendor, tool, source, project, extra):
    if vendor == "transsion":
        config = ARTIFACT / "transsion" / "mock-config"
        if not config.exists():
            config.mkdir()
            sheets = {
                "packages.xlsx": [["应用包名", "模块", "负责人"], *[
                    [token, "AUTOTEST", "review-user"] for token, _ in CASE.values()]],
                "probability.xlsx": [["概率", "是否加偶现标签", "标题附加词语"]],
                "test-summary.xlsx": [["测试项", "编号", "测试总次数", "测试步骤"], ["Monkey专项", 1, 20, "synthetic review"]],
            }
            for filename, rows in sheets.items():
                book = openpyxl.Workbook()
                for row in rows:
                    book.active.append(row)
                book.save(config / filename)
            (config / "regex.txt").write_text('"^.*$": "AUTOTEST"\n')
        extra = [*extra, "--package-mapping-file", config / "packages.xlsx",
                 "--probability-rules-file", config / "probability.xlsx",
                 "--test-summary-file", config / "test-summary.xlsx",
                 "--component-regex-file", config / "regex.txt"]
    opts = ["--assignee-auto"] if vendor == "transsion" else ["--set-assignee", "review-user"]
    return [ROOT / "safe_generate_cli.py", vendor, tool, "--add-main-excel", source,
            "--set-project-key", project, "--set-test-case", "Monkey专项",
            "--set-reporter", "review-user", *opts, *extra]

def execute(vendor, tool, project, version, work, workbook, extra=(), historical_id=None, runner_cwd=None,
            fail_update=False, reject=True):
    cfg = work / "mock-jira-input.json"
    write(cfg, dict(project=project, version=version, historical_id=historical_id,
                    fail_update=fail_update, reject=reject, tokens=[token for token, _ in CASE.values()]))
    audit = work / "mock-jira-calls.json"
    rc = run(runner_cwd or work, work / "create.log",
             [ROOT / "fake_jira_cli.py", vendor, tool, cfg, audit,
              "--add-excel-file", workbook, *extra])
    return rc, read(audit)

def links(payload):
    return sorted([x["signature_id"], x["occurrence_id"], x["occurrence_key"], x["issue_key"]]
                  for x in payload["links"])

def link_for(sid, oids, project_key):
    return [[sid, oid, key(sid, oid), project_key] for oid in oids]

def load_output(vendor, work):
    payload = read(work / "attribution.json")
    result = read(only((work / "result").glob("*_jira_batch_create_result_*.json")))
    assert isinstance(result, list)
    only((work / "result").glob("*_jira_batch_create_summary_*.xlsx"))
    assert payload["schema"] == "stp.jira_attribution/v1"
    assert payload["contract_version"] == "b8-g8-attribution-v1"
    assert payload["stage"] == "create" and payload["tool"] == vendor
    return payload, result

def sorted_subset(vendor, tool, project, version, work, output, offset, extra, cwd):
    reviewed = work / "reviewed-reordered-filtered.xlsx"
    select = [73 + offset, 72 + offset, 71 + offset]
    prepare_review(output, reviewed, select)
    rc, calls = execute(vendor, tool, project, version, work, reviewed, extra,
                        historical_id=72 + offset, runner_cwd=cwd)
    payload, result = load_output(vendor, work)
    check(vendor, f"{work.name} nonzero exit for simulated rejected row", 1, rc)
    check(vendor, f"{work.name} result statuses follow reviewed order",
          ["FAILED", "SUCCESS", "SUCCESS"], [row["status"] for row in result])
    check(vendor, f"{work.name} create calls skip history and filtered-out rows",
          ["review.reject", "review.new"], [x["token"] for x in calls["create"]])
    check(vendor, f"{work.name} history update key", [f"{project}-99001"], calls["update"])
    expected = sorted(link_for(71 + offset, [101 + offset, 102 + offset], f"{project}-99102") +
                      link_for(72 + offset, [201 + offset, 202 + offset], f"{project}-99001"))
    check(vendor, f"{work.name} exact links including original occurrence keys", expected, links(payload))
    check(vendor, f"{work.name} result carries original signature IDs in edited order", select,
          [row["signature_id"] for row in result])
    check(vendor, f"{work.name} result stable ID sets and attribution statuses agree with attribution.json",
          [[row[k] for k in ("signature_id", "occurrence_ids", "attribution_status", "status")]
           for row in result],
          [[row[k] for k in ("signature_id", "occurrence_ids", "attribution_status", "status")]
           for row in payload["items"]])
    check(vendor, f"{work.name} original manifest run binding", [991 + bool(offset), 1 + bool(offset)],
          [payload["run"]["plan_run_id"], payload["run"]["delivery_version_no"]])
    return payload

def negative(vendor, tool, project, version, home, output, manifest_path):
    work = home / "negative"
    work.mkdir()
    reviewed = work / "reviewed-negative.xlsx"
    edits = {
        75: {"Occurrence IDs": None},
        76: {"Signature ID": "76.75"},
        77: {"Occurrence IDs": "[701, 1001]"},
        79: {"Signature ID": None},
        80: {"Occurrence IDs": '["junk"]'},
        81: {"Occurrence IDs": "[1101.75]"},
        82: {"Occurrence Keys": '["wrong-occurrence-key"]'},
    }
    select = [75, 76, 77, 78, 78, 79, 80, 81, 82]
    prepare_review(output, reviewed, select, edits)
    rc, calls = execute(vendor, tool, project, version, work, reviewed,
                        ["--output-dir", work, "--attribution-manifest", manifest_path])
    payload, result = load_output(vendor, work)
    check(vendor, "blank subset must never add omitted manifest-only occurrence 502", False,
          any(link["occurrence_id"] == 502 for link in payload["links"]))
    check(vendor, "invalid or lost identifiers must not link", [], links(payload))
    for row, expected_gap in {
        2: "missing_occurrence_id", 3: "invalid_signature_id", 4: "out_of_scope_occurrence_id",
        5: "duplicate_occurrence_id", 6: "duplicate_occurrence_id",
        7: "missing_signature_id", 8: "invalid_occurrence_id",
        9: "invalid_occurrence_id", 10: "occurrence_key_mismatch",
    }.items():
        recorded = next((x["kind"] for x in payload["gaps"] if x["workbook_row"] == row), None)
        check(vendor, f"workbook row {row} attribution gap", expected_gap, recorded)
    check(vendor, "duplicate same occurrence across two rows zero create calls",
          0, sum(x["token"] == "review.duplicate" for x in calls["create"]))
    check(vendor, "both copied rows SKIPPED", ["SKIPPED", "SKIPPED"],
          [row["status"] for row in payload["items"] if row["workbook_row"] in (5, 6)])

def output_paths(directory):
    return sorted(str(path.relative_to(directory)) for path in directory.glob("*")
                  if path.is_file() and path.suffix in {".json", ".xlsx"})

def scope(vendor):
    dirname, project, version = VENDOR[vendor]
    head = ROOT / "head" / SUITE / dirname
    home = ARTIFACT / vendor
    home.mkdir()
    explicit, auto, caller = (home / name for name in ("explicit", "auto", "caller"))
    for path in (explicit, auto, caller):
        path.mkdir()
    for out, off in [(explicit, 0), (auto, 10000)]:
        is_explicit = out == explicit
        source = (caller if is_explicit else out) / "delivery.xls"
        fixture(source, version, off)
        manifest_path = (caller / "bound-input.json") if is_explicit else auto / "manifest.json"
        data = {sid + off: [oid + off for oid in ids] for sid, (_, ids) in CASE.items()}
        manifest(manifest_path, data, 991 + bool(off), 1 + bool(off))
        before_auto = output_paths(explicit) if not is_explicit else []
        before_result = output_paths(head / "result")
        extra = ["--output-dir", out, "--attribution-manifest", manifest_path] if is_explicit else []
        cwd = caller if is_explicit else out
        rc = run(cwd, out / "generate.log", gen_args(vendor, head, source, project, extra))
        assert rc == 0, out / "generate.log"
        output = only(out.glob("JIRA_Upload_List_*.xlsx"))
        gen = read(out / "attribution_input.json")
        assert gen["schema"] == "stp.jira_attribution/v1" and gen["stage"] == "generate"
        headings, rows = sheet_rows(output)
        sig_col = headings.index("Signature ID")
        occ_col = headings.index("Occurrence IDs")
        status_col = headings.index("Attribution Status")
        merged = [[json.loads(r[occ_col]), r[status_col]] for r in rows if int(r[sig_col]) == 71 + off]
        check(vendor, f"{out.name} actual generated XLSX multi-row merge",
              [[[101 + off, 102 + off], "MERGED"]], merged)
        check(vendor, f"{out.name} generation evidence ID sets",
              [101 + off, 102 + off], next(x["occurrence_ids"] for x in gen["items"] if x["signature_id"] == 71 + off))
        check(vendor, f"{out.name} generation gaps", [], gen["gaps"])
        sorted_subset(vendor, head, project, version, out, output, off, extra, cwd)
        check(vendor, f"{out.name} no default result file overwritten", before_result, output_paths(head / "result"))
        if not is_explicit:
            check(vendor, "auto keeps explicit workspace root outputs", before_auto, output_paths(explicit))
        else:
            explicit_workbook = output
            explicit_manifest = manifest_path
    check(vendor, "explicit caller contains only input manifest among JSON/XLSX", ["bound-input.json"],
          output_paths(caller))
    negative(vendor, head, project, version, home, explicit_workbook, explicit_manifest)
    hidden = home / "excel-visibility-filter"
    hidden.mkdir()
    reviewed = hidden / "reviewed-autofilter.xlsx"
    prepare_review(explicit_workbook, reviewed, [74, 71], hide=74)
    execute(vendor, head, project, version, hidden, reviewed,
            ["--output-dir", hidden, "--attribution-manifest", explicit_manifest])
    payload, _ = load_output(vendor, hidden)
    check(vendor, "Excel AutoFilter only visible row is linked", [71],
          sorted({x["signature_id"] for x in payload["links"]}))
    for rev in ("base", "head"):
        tool = ROOT / rev / SUITE / dirname
        legacy = home / f"legacy-{rev}"
        legacy.mkdir()
        source = legacy / "delivery.xls"
        fixture(source, version, 0)
        before = set((tool / "result").glob("JIRA_Upload_List_*.xlsx"))
        rc = run(legacy, legacy / "generate.log", gen_args(vendor, tool, source, project, []))
        assert rc == 0, legacy / "generate.log"
        workbook = only(set((tool / "result").glob("JIRA_Upload_List_*.xlsx")) - before)
        check(vendor, f"{rev} legacy generated without attribution columns", False,
              "Signature ID" in sheet_rows(workbook)[0])
        before_results = set((tool / "result").glob("*_jira_batch_create_result_*.json"))
        rc, calls = execute(vendor, tool, project, version, legacy, workbook, reject=False)
        result_file = only(set((tool / "result").glob("*_jira_batch_create_result_*.json")) - before_results)
        check(vendor, f"{rev} legacy no attribution artifacts/fields", [False, False, False],
              [(legacy / "attribution.json").exists(), (tool / "attribution.json").exists(),
               any("signature_id" in row for row in read(result_file))])
        check(vendor, f"{rev} legacy actual mock create rows", len(sheet_rows(workbook)[1]),
              len(calls["create"]))
        check(vendor, f"{rev} legacy create exit", 0, rc)
        write(legacy / "actual-output-locations.json", dict(workbook=str(workbook), result=str(result_file), rc=rc))
    optional_real = os.getenv("REVIEW_REAL_WORKBOOK")
    if optional_real:
        # Real data is local review evidence. It is outside the publishable sample tree.
        real = ROOT / "real-workbook" / vendor
        real.mkdir(parents=True)
        sheet = xlrd.open_workbook(optional_real).sheet_by_index(0)
        hdr = sheet.row_values(0)
        n = 80000
        data = {}
        for i in range(1, sheet.nrows):
            row = dict(zip(hdr, sheet.row_values(i)))
            count = int(row["Count"])
            data[int(row["Id"])] = list(range(n, n + count))
            n += count
        manifest(real / "manifest.json", data, 993, 1)
        real_project = "PFDFAA" if vendor == "tinno" else project
        run(real, real / "generate.log", gen_args(vendor, head, Path(optional_real), real_project, []))
        output = only(real.glob("JIRA_Upload_List_*.xlsx"))
        headings, rows = sheet_rows(output)
        ids = [int(row[headings.index("Signature ID")]) for row in rows]
        check(vendor, "real source actual generated XLSX covers signature set", sorted(data), sorted(ids))
        reviewed = real / "reviewed.xlsx"
        prepare_review(output, reviewed, [1, 0])
        execute(vendor, head, real_project, "MLD-NX3-16-261104V80", real, reviewed, historical_id=1)
        payload, _ = load_output(vendor, real)
        check(vendor, "real source exact occurrence coverage after reordering/filtering",
              sorted([sid, oid] for sid in (0, 1) for oid in data[sid]),
              sorted([x["signature_id"], x["occurrence_id"]] for x in payload["links"]))

try:
    scope(sys.argv[1])
finally:
    write(ARTIFACT / f"{sys.argv[1]}-checks.json", CHECKS)
    write(ARTIFACT / f"{sys.argv[1]}-commands.json", COMMANDS)

raise SystemExit(0 if all(x["passed"] for x in CHECKS) else 1)
