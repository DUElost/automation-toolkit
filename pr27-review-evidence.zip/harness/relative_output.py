"""Probe relative --output-dir for both shipped CLI entry points."""
import sys
from pathlib import Path

script = Path(__file__).with_name("review_cli.py")
namespace = {"__file__": str(script), "__name__": "review_helpers"}
exec(compile(script.read_text().split("\ntry:\n    scope(sys.argv[1])")[0], str(script), "exec"), namespace)
ROOT, SUITE, ARTIFACT, VENDOR = (namespace[x] for x in ("ROOT", "SUITE", "ARTIFACT", "VENDOR"))
run, gen_args, execute, write, only = (namespace[x] for x in ("run", "gen_args", "execute", "write", "only"))

vendor = sys.argv[1]
dirname, project, version = VENDOR[vendor]
tool = ROOT / "head" / SUITE / dirname
home = ARTIFACT / vendor
caller = home / "relative-caller"
caller.mkdir()
out = caller / "review-relative-output"
out.mkdir()
manifest = home / "caller" / "bound-input.json"
options = ["--output-dir", out.name, "--attribution-manifest", manifest]
source = home / "caller" / "delivery.xls"
rc = run(caller, out / "generate.log", gen_args(vendor, tool, source, project, options))
assert rc == 0
workbook = only(out.glob("JIRA_Upload_List_*.xlsx"))
rc, calls = execute(vendor, tool, project, version, out, workbook, options,
                    runner_cwd=caller, reject=False)
assert rc == 0
script_result = tool / out.name / "result"
facts = dict(workspace=str(out), attribution=(out / "attribution.json").is_file(),
             batch_result=[p.name for p in (out / "result").glob("*_result_*.json")],
             expected_workspace_summary=[p.name for p in (out / "result").glob("*_summary_*.xlsx")],
             unexpected_script_dir_summary=[p.name for p in script_result.glob("*_summary_*.xlsx")])
write(out / "paths-observed.json", facts)
write(out / "commands.json", namespace["COMMANDS"])
print(facts)
