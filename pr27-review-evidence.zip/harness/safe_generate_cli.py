"""Generate with the actual CLI while removing the unrelated log-server access block."""
import importlib
import sys

vendor, tool, *args = sys.argv[1:]
sys.path.insert(0, tool)
entry = importlib.import_module(f"generate_{vendor}_jira_upload_list")
module = importlib.import_module("jira_issue_template" if vendor == "tinno"
                                 else "transsion_upload_template_common")
module.build_log_server_access_text = lambda: "Review fixture: no log-server access."
sys.argv = [entry.__file__, *args]
raise SystemExit(entry.main())
