"""Exercise the existing Jira connectivity helper against an in-process HTTP server."""
import importlib.util
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread

visits = []
class JiraStub(BaseHTTPRequestHandler):
    def do_GET(self):
        visits.append(self.path)
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b'{"version": "mock-review"}')

with HTTPServer(("127.0.0.1", 0), JiraStub) as server:
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        spec = importlib.util.spec_from_file_location("vendor_network_check", sys.argv[1])
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        assert module.test_server_connection(f"http://127.0.0.1:{server.server_port}") is True
        assert visits == ["/", "/rest/api/2/serverInfo"], visits
        print("PASS", visits)
    finally:
        server.shutdown()
        thread.join()
