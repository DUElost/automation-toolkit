"""Run the checked-out batch CLI with a process-local Jira substitute."""
import importlib
import json
import socket
import sys
from pathlib import Path
from types import SimpleNamespace as NS

import pandas as pd

vendor, tool, fixture_path, audit_path, *args = sys.argv[1:]
sys.path.insert(0, tool)
cli = importlib.import_module(f"create_{vendor}_jira_batch_from_excel")
jira_config = json.loads(Path(fixture_path).read_text())
calls = {"create": [], "search": 0, "update": [], "comments": 0}
password = "review-placeholder"
version = jira_config["version"]
project = jira_config["project"]
historic_key = f"{project}-99001"
historical_id = jira_config.get("historical_id")
mock_server = "http://jira.invalid"
history_fields = None

def offline(*args, **kwargs):
    raise AssertionError("Independent review blocks network connections")

socket.socket.connect = offline
socket.socket.connect_ex = offline

class Jira:
    auth_mode = "mock"

    def current_user(self):
        return "review-user"

    def project(self, key):
        return NS(key=key)

    def user(self, name):
        return NS(name=name, displayName=name)

    def search_users(self, name, **kwargs):
        return [self.user(name)]

    def close(self):
        pass

    def createmeta(self, projectKeys, expand):
        fields = {"summary": {"name": "Summary"}, "versions": {
            "name": "Versions", "allowedValues": [{"name": version}]}}
        return {"projects": [{"key": projectKeys, "issuetypes": [
            {"name": name, "fields": fields} for name in ("故障", "Bug")]}]}

    def get_project_version_by_name(self, key, name):
        return NS(name=name)

    def create_issue(self, fields):
        summary = fields["summary"]
        key = f"{project}-{99101 + len(calls['create'])}"
        package = next((t for t in sorted(jira_config["tokens"], key=len, reverse=True) if t in summary), None)
        calls["create"].append({"key": key, "token": package})
        if package == "review.reject" and jira_config.get("reject", True):
            raise RuntimeError("mock Jira refused issue creation")
        return NS(key=key) if vendor == "transsion" else {"key": key}

    def issue(self, key):
        fields = history_fields if key == historic_key else {}
        return NS(key=key, raw={"fields": fields},
                  fields=NS(status=NS(name="Open")),
                  update=lambda fields: self.update_issue(key, fields))

    def get_issue(self, key):
        return {"key": key, "fields": history_fields if key == historic_key else {}}

    def add_attachment(self, **kwargs):
        pass

    def search_issues(self, *args, **kwargs):
        calls["search"] += 1
        return [NS(key=historic_key)] if history_fields is not None else []

    def get_issue_comments(self, key):
        return {"comments": []}

    def comments(self, key):
        return []

    def add_comment(self, key, text):
        calls["comments"] += 1

    def update_issue(self, key, fields):
        calls["update"].append(key)

jira = Jira()
cli.connect_to_jira = lambda *args, **kwargs: jira

if historical_id is not None:
    excel = args[args.index("--add-excel-file") + 1]
    df = pd.read_excel(excel, engine="openpyxl")
    target = next(row for _, row in df.iterrows()
                  if str(row.get("Signature ID")) == str(historical_id))
    if vendor == "tinno":
        defaults = cli.load_defaults(cli.DEFAULT_CONFIG_FILE)
        record = cli.build_regression_row(target, defaults)
        rules = cli.load_regression_rules(cli.DEFAULT_REGRESSION_RULES_FILE)
        db_path = cli.build_project_history_db_path(mock_server, project,
                                                    sqlite_path_setting=rules.output.sqlite_path)
        database = cli.DatabaseManager({"type": "sqlite", "path": str(db_path)})
        if database.get_issue_by_key(historic_key) is None:
            database.insert_issue({"jira_key": historic_key, "build_version": version,
                                   "summary": str(record["summary"]), "status": "Open",
                                   "normalized_summary": str(record["summary"]),
                                   "test_environment": str(record["environment"]),
                                   "raw_caused_by": str(record["caused_by"]),
                                   "package_name": "review.history",
                                   "bug_severity": "B", "priority": "Medium"})
        database.close()
    else:
        record = cli.build_regression_row(target)
    history_fields = {field: record[field] for field in
                      ("summary", "environment", "affect_project", "exp_class", "caused_by")}
    history_fields["status"] = {"name": "Open"}
    history_fields["project"] = {"key": project}
    if jira_config.get("fail_update"):
        def refuse_update(key, fields):
            calls["update"].append(key)
            raise RuntimeError("mock Jira refused history update")
        jira.update_issue = refuse_update

sys.argv = [cli.__file__, "--jira-server", mock_server, "--jira-username", "review-user",
            "--jira-password", password, "--wait-between-issues", "0", *args]
if vendor == "tinno":
    sys.argv += ["--jira-p12-path", "unused-mock.p12", "--jira-p12-password", password, "--no-add-comments"]
try:
    result = cli.main()
finally:
    Path(audit_path).write_text(json.dumps(calls, indent=2) + "\n")
raise SystemExit(result)
